#ifndef VALIDATIONS_H
#define VALIDATIONS_H

#include<common.h>
#include<ctype.h>

int validName(char name[]);

int validPhoneno(long int phoneno);

int validPassword(char password[]);

#endif 
